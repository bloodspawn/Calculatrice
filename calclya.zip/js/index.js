objdiv = document.getElementById('calculatrice');
objecran = document.getElementById('ecran');
tab = [];
function remptab(val){
  tab.push(val);
  objecran.innerHTML += val+" ";
}

for(i=0;i<10;i++){
  objdiv.innerHTML += "<button value='"+i+"' onclick='remptab(this.value)'>"+i+"</button>";
}
objdiv.innerHTML += "<button value='+' onclick='remptab(this.value)'>+</button>";
objdiv.innerHTML += "<button value='-' onclick='remptab(this.value)'>-</button>";
objdiv.innerHTML += "<button value='*' onclick='remptab(this.value)'>*</button>";
objdiv.innerHTML += "<button value='/' onclick='remptab(this.value)'>/</button>";
objdiv.innerHTML += "<button value='.' onclick='remptab(this.value)'>.</button>";
objdiv.innerHTML += "<button value='(' onclick='remptab(this.value)'>(</button>";
objdiv.innerHTML += "<button value=')' onclick='remptab(this.value)'>)</button>";
objdiv.innerHTML += "<button value='/100' onclick='remptab(this.value)'></button>";
objdiv.innerHTML += "<button id='reset' value='=' onclick='reset()'>reset</button>";

objdiv.innerHTML += "<button value='=' onclick='recup=calcul(tab);recup()'>=</button>";
function calcul(tabo){
  chaine = tab.join('');
  function affiche(nb){
    objecran.innerHTML = eval(chaine) ;
  }
  return affiche;
  tab=new Array();
}
function reset(){
  objecran.innerHTML = '';
  tab=new Array();
}